/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User_side;

/**
 *
 * @author abdul
 */
public class user {
    private String name;
    private String enroll;
    private int attempt;
    private int obtained;
    private int tmarks;
    
    user(){}
    user(String n,String e,int a,int o,int t)
    {
        name=n;
        enroll=e;
        attempt=a;
        obtained=o;
        tmarks=t;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the enroll
     */
    public String getEnroll() {
        return enroll;
    }

    /**
     * @param enroll the enroll to set
     */
    public void setEnroll(String enroll) {
        this.enroll = enroll;
    }

    /**
     * @return the attempt
     */
    public int getAttempt() {
        return attempt;
    }

    /**
     * @param attempt the attempt to set
     */
    public void setAttempt(int attempt) {
        this.attempt = attempt;
    }

    /**
     * @return the obtained
     */
    public int getObtained() {
        return obtained;
    }

    /**
     * @param obtained the obtained to set
     */
    public void setObtained(int obtained) {
        this.obtained = obtained;
    }

    /**
     * @return the tmarks
     */
    public int getTmarks() {
        return tmarks;
    }

    /**
     * @param tmarks the tmarks to set
     */
    public void setTmarks(int tmarks) {
        this.tmarks = tmarks;
    }
    
}

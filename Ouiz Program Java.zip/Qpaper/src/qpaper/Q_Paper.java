/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qpaper; 

import User_side.user;
import java.io.Serializable;

/**
 *
 * @author abdul
 */
public class Q_Paper implements Serializable{
    private String Password;
    private String Subject;
    private int no_user;
    private int time;
    private int marks;
    public String Instructor;
    public Questions qs[];
    private int c_q=0;
    private String I_roll;
    
    Q_Paper(){}
    Q_Paper(String Password,String Subject,int time,int no_qs,String Instructor,String eroll)
    {
        this.Password=Password;
        this.Subject=Subject;
        this.marks=no_qs;
        this.time=time;
        this.Instructor=Instructor;
        this.I_roll=eroll;
        qs=new Questions[marks];
    }
    
    public Questions add_question()
    {
        Questions qtn=new Questions();
        qs[this.getC_q()]=qtn;
        this.setC_q(this.getC_q() + 1);
        return qtn;
    }

    /**
     * @return the Password
     */
    public String getPassword() {
        return Password;
    }

    /**
     * @param Password the Password to set
     */
    public void setPassword(String Password) {
        this.Password = Password;
    }

    /**
     * @return the Subject
     */
    public String getSubject() {
        return Subject;
    }

    /**
     * @param Subject the Subject to set
     */
    public void setSubject(String Subject) {
        this.Subject = Subject;
    }

    /**
     * @return the no_user
     */
    public int getNo_user() {
        return no_user;
    }

    /**
     * @param no_user the no_user to set
     */
    public void setNo_user(int no_user) {
        this.no_user = no_user;
    }

    /**
     * @return the time
     */
    public int getTime() {
        return time;
    }

    /**
     * @param time the time to set
     */
    public void setTime(int time) {
        this.time = time;
    }

    /**
     * @return the marks
     */
    public int getMarks() {
        return marks;
    }

    /**
     * @param marks the marks to set
     */
    public void setMarks(int marks) {
        this.marks = marks;
        qs=new Questions[marks];
    }

    /**
     * @return the I_roll
     */
    public String getI_roll() {
        return I_roll;
    }

    /**
     * @param I_roll the I_roll to set
     */
    public void setI_roll(String I_roll) {
        this.I_roll = I_roll;
    }

    /**
     * @return the c_q
     */
    public int getC_q() {
        return c_q;
    }

    /**
     * @param c_q the c_q to set
     */
    public void setC_q(int c_q) {
        this.c_q = c_q;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qpaper;

import java.io.Serializable;

/**
 *
 * @author abdul
 */
public class Questions implements Serializable{
    private int a_True;
    private int u_answer;
    private boolean state;
    public String q;
    public String ans[];
    Questions()
    {
        ans=new String[4];
        state=false;
        q="";
        ans[0]="";
        ans[1]="";
        ans[2]="";
        ans[3]=""; 
    }
    
Questions(String Q,String ans[],int a_t)
{
     this.ans=new String[4];
        state=false;
        q=Q;
        
        this.a_True=a_t;
        
        this.ans[0]=ans[0];
        this.ans[1]=ans[1];
        this.ans[2]=ans[2];
        this.ans[3]=ans[3]; 
   }

    /**
     * @return the a_True
     */
    public int getA_True() {
        return a_True;//a_True = Answer True
    }

    /**
     * @param a_True the a_True to set
     */
    public void setA_True(int a_True) {
        this.a_True = a_True;
    }

    /**
     * @return the u_answer
     */
    public int getU_answer() {
        return u_answer;// u_answer=User Answer
    }

    /**
     * @param u_answer the u_answer to set
     */
    public void setU_answer(int u_answer) {
        this.u_answer = u_answer;
    }

    /**
     * @return the state
     */
    public boolean isState() {
        return state;
    }

    /**
     * @param state the state to set
     */
    public void setState(boolean state) {
        this.state = state;
    }
}        



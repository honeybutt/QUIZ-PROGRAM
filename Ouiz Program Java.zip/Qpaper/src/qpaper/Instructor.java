/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qpaper;

/**
 *
 * @author abdul
 */
public class Instructor {
    private String UserName;
    private String Password;
    public String Enroll;
    public String name; 

    Instructor()
    {}
    Instructor(String u,String p,String n,String e)
    {
        this.UserName=u;
        this.name=n;
        this.Password=p;
        this.Enroll=e;
    }
    
    /**
     * @return the UserName
     */
    public String getUserName() {
        return UserName;
    }

    /**
     * @param UserName the UserName to set
     */
    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    /**
     * @return the Password
     */
    public String getPassword() {
        return Password;
    }

    /**
     * @param Password the Password to set
     */
    public void setPassword(String Password) {
        this.Password = Password;
    }
    
    
}

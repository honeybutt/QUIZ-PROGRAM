/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qpaper;

/**
 *
 * @author abdul
 */
public class Qpaper {

    /**
     * @param args the command line arguments
     */
    public static String ctos(char c[])
    {
        String str="";
        for (char c1 : c)
        {    
            str += c1;
        }
        return str;
    }
    public static void main(String[] args) {
        Login i=new Login();
        i.setVisible(true);
        // TODO code application logic here
    }
    
}
